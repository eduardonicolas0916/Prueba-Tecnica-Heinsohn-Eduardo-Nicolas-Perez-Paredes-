package peduardo.AddNumbersRESTService;

import javax.ws.rs.core.Context;
import javax.ws.rs.core.UriInfo;
import javax.ws.rs.Produces;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;

/**
 * REST Web Service that allows add two numbers specificated as path parameters
 * Example: http://localhost:8080/AddNumbersRESTService/resources/addnumbers/1/3 will add '1' and '3' and throws '4' as result.
 *
 * @author Eduardo Nicolás Pérez Paredes
 */
@Path("addnumbers")
public class AddNumbers {

    @Context
    private UriInfo context;

    /**
     * Default constructor.
     */
    public AddNumbers() {
    }

    /** 
     * Uses the @GET method to add two numbers specified in the @Path url and @Produces a HTML TEXT response
     * 
     * @param first_number The first addend of the operation
     * @param second_number The second addend of the operation
     * 
     * @return A message with the result of adding 'first_number' and 'second_number'
     */
    @GET
    @Path("/{first_number}/{second_number}")
    @Produces("text/html")
    public String sumar(@PathParam("first_number") int first_number, @PathParam("second_number") int second_number) {
        return "La suma de " + first_number + " y " + second_number + " da como resultado: " +(first_number + second_number);
    }
}
package Logic;

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

/**
 * This class allows to write to a plain text file
 * (Note: If the file doesn't exists it will be created
 * If the file already exists it will be overwrited).
 * 
 * @author Eduardo Nicolás Pérez Paredes
 */
public class WriteFile {

    /**
     * Default constructor.
     */
    public WriteFile(){}
    
    /**
     * Writes to a plain text file (.txt) the content specified in 'content' in the path 'path'. 
     * 
     * @param path Path where the file will be created/overwritten.
     * @param content Content to be written to file.
     * @param answerFileName Name of the anwser file.
     * 
     * @throws IOException If there is a problem with file manipulation
     */
    @SuppressWarnings("null")
    public void writeInFile(String path, ArrayList<String> content, String answerFileName) throws IOException{
        
        FileWriter file = null;
        @SuppressWarnings("UnusedAssignment")
        PrintWriter writer = null;
        
        try{
            file = new FileWriter(path + answerFileName);
            writer = new PrintWriter(file);
            for(String lineContent : content){
                writer.println(lineContent);
            }
            System.out.println("El archivo '" + answerFileName + "' fue creado/sobreescrito satisfactoriamente y se encuentra en el paquete 'Assets'");
        }catch(IOException e){
            System.out.println("Error: " + e.getMessage());
        } finally{
            file.close();
        }
    }
}

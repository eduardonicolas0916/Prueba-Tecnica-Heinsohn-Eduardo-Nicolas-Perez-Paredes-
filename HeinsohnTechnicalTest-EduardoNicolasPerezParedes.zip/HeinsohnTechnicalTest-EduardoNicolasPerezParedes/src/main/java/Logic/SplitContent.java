package Logic;

import java.util.ArrayList;
import java.util.Arrays;

/**
 * Class that allows you to split the content of a string using a specific delimiter.
 * 
 * @author Eduardo Nicolás Pérez Paredes
 */
public class SplitContent {
    
    /**
     * Default constructor.
     */
    public SplitContent(){}
        
    /**
     * Allows to split a string using a specific delimiter (if there is nothing after a delimiter it is interpreted as an empty string).
     * 
     * @param string The string to be split
     * @param delimiter The delimiter used to split the string
     * 
     * @return An array that contains the splitted string.
     */
    public ArrayList<String> splitString(String string, String delimiter){
        //The limit value is set to -1 so that, when there is nothing after a delimiter, it is taken as an empty string.
        ArrayList<String> splittedString = new ArrayList<>(Arrays.asList(string.split(delimiter, -1)));
        return splittedString;          
    }
}
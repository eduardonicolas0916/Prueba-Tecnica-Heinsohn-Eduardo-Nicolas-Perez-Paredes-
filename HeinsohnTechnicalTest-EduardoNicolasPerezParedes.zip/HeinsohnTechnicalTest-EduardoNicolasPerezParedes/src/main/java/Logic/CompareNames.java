package Logic;

import java.util.ArrayList;

/**
 * Class that allows comparing whether two names are the same or not (first and last names are compared).
 * 
 * @author Eduardo Nicolás Pérez Paredes
 */
public class CompareNames {
      
    /**
     * Default constructor.
     */
    public CompareNames(){}
           
    /**
     * Compares two names (first and last names) and returns whether they are the same or not
     * (Note: This method is case sensitive and also distinguishes accents or other special characters).
     * 
     * @param namesToCompare Array with the names to be compared
     * 
     * @return Boolean that indicates if two names are the same or not.
     */
    public boolean sameNames(ArrayList<String> namesToCompare){
        boolean same = false;
        if(namesToCompare.get(0).equals(namesToCompare.get(4))){
            if(namesToCompare.get(1).equals(namesToCompare.get(5))){
                if(namesToCompare.get(2).equals(namesToCompare.get(6))){
                    if(namesToCompare.get(3).equals(namesToCompare.get(7))){
                        same = true;
                    }
                }
            }
        }
        return same;
    }
}
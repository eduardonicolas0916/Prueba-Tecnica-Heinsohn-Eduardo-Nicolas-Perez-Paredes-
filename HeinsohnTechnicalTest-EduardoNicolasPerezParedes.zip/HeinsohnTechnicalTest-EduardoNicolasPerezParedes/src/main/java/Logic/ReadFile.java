package Logic;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

/**
 * Class that allows to read a plain text file (.txt) and save its content by lines.
 * 
 * @author Eduardo Nicolás Pérez Paredes
 */
public class ReadFile {
          
    /**
     * Default constructor.
     */
    public ReadFile(){}
    
            
    /**
     * Reads a txt file line by line located in 'path' and stores the lines readed into an ArrayList named 'fileContent'.
     * 
     * @param path Indicates the path where the file is alocated.
     * 
     * @return The file content saved by lines.
     */
    public ArrayList<String> ReadTxtFile(String path){
                       
        ArrayList<String> fileContent = new ArrayList<>();
        try (BufferedReader reader = new BufferedReader(new FileReader(path))){
            String line;
            while ((line = reader.readLine()) != null) {
                fileContent.add(line);
            }
        } catch (IOException e) {
            System.out.println("Error: " + e.getMessage());
        } 
        
        return fileContent;
    }
}
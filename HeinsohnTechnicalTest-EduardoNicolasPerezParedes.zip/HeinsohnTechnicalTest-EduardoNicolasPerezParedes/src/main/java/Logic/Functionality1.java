package Logic;

import java.io.IOException;
import java.util.ArrayList;

/**
 * This class allows to read records from a plain text file (.txt) separated by ";" 
 * and then identify if the first and last names are the same,
 * in addition, it generates a new plain text file (.txt) with the answer
 *
 * The structure of the plain text file must be as follows:
 * 
 * Person1FirstName;Person1MiddleName;Person1LastName1;Person1LastName2;Person2FirstName;Person2MiddleName;Person2LastName1;Person2LastName2
 * 
 * @author Eduardo Nicolás Pérez Paredes
 */
public class Functionality1 {
    
    /**
     * Reads the plain text file located in 'namesFilePath' and save its content by lines,
     * split the content of each line by 'delimeter',
     * compare if both names in the file are the same or not,
     * create a new plain text file named 'answerFileName' located in 'answerPathFile'.
     *  
     * @param namesFilePath Path to the plain text file (.txt) containing the names .
     * @param delimeter The delimiter used to split the string.
     * @param answerPathFile Path where the new file will be located.
     * @param answerFileName Name of the new file containing the answer.
     * 
     * @throws IOException If there is a problem with file manipulation
     */
    public void runFuncionality1(String namesFilePath, String delimeter, String answerPathFile, String answerFileName) throws IOException{
        ReadFile readFile = new ReadFile();
        SplitContent splitContent = new SplitContent();
        CompareNames compareNames = new CompareNames();
        WriteFile writeFile = new WriteFile();
    
        ArrayList<String> tempLines = readFile.ReadTxtFile(namesFilePath);
        ArrayList<String> newLines = new ArrayList<>();
        ArrayList<String> splittedLines = new ArrayList<>();
        for(String tempLine : tempLines){
            splittedLines = splitContent.splitString(tempLine, delimeter);
            if(compareNames.sameNames(splittedLines)){
                tempLine = tempLine + ";IGUAL";
            }else{
                tempLine = tempLine + ";DIFERENTE";
            }
            newLines.add(tempLine);
        }
        writeFile.writeInFile(answerPathFile, newLines, answerFileName);
    }
}
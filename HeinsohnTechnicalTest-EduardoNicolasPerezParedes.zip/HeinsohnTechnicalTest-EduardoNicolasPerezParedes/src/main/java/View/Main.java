package View;

import Logic.Functionality1;
import java.io.IOException;

/**
 * Class that allows the application to run
 * 
 * @author Eduardo Nicolás Pérez Paredes
 */
public class Main {
    
    /**
     * Allows to execute the application.
     * 
     * @throws IOException If there is a problem with file manipulation. 
     */    
    public static void runMain() throws IOException{
        Functionality1 funcionality1 = new Functionality1();
        funcionality1.runFuncionality1("src\\main\\java\\Assets\\names.txt", ";", "src\\main\\java\\Assets\\", "names_compared.txt"); //Execute funcionality 1
    }
      
    /**
     * 
     * @param args The command line arguments.
     * 
     * @throws IOException If there is a problem with file manipulation. 
     */
    public static void main(String[] args) throws IOException {
        runMain();
    }
}